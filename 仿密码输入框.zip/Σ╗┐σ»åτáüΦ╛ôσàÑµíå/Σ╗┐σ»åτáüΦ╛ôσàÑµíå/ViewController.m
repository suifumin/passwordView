//
//  ViewController.m
//  仿密码输入框
//
//  Created by suifumin on 2017/11/2.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import "ViewController.h"
#import "passwordView.h"
#define VIEWWIDTH  [UIScreen mainScreen].bounds.size.width
#define VIEWHEIGHT [UIScreen mainScreen].bounds.size.height
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *jumpButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [jumpButton setTitle:@"弹出密码输入框" forState:UIControlStateNormal];
    [jumpButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    jumpButton.layer.borderWidth = 1;
    jumpButton.layer.borderColor = [UIColor greenColor].CGColor;
    [jumpButton addTarget:self action:@selector(clickJumpButton) forControlEvents:UIControlEventTouchDown];
    jumpButton.frame = CGRectMake(120, 100, VIEWWIDTH-240, 50);
    [self.view addSubview:jumpButton];
   
}
-(void)clickJumpButton{
    passwordView *passView = [[passwordView alloc]initWithFrame:CGRectMake(100, 200,VIEWWIDTH-200 , 200)];
    [self.view addSubview:passView];
    
}
@end
