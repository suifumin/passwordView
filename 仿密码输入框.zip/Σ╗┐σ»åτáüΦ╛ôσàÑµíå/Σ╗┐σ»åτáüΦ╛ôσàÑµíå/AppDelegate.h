//
//  AppDelegate.h
//  仿密码输入框
//
//  Created by suifumin on 2017/11/2.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

