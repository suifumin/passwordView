//
//  passwordView.m
//  仿密码输入框
//
//  Created by suifumin on 2017/11/2.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import "passwordView.h"
#define VIEWWIDTH  [UIScreen mainScreen].bounds.size.width
#define VIEWHEIGHT [UIScreen mainScreen].bounds.size.height
@implementation passwordView

-(instancetype)initWithFrame:(CGRect)frame{
    if(self= [super initWithFrame:frame]){
        self.hideTextfiled = [[UITextField alloc]initWithFrame:self.bounds];
        [self addSubview:_hideTextfiled];
        [self.hideTextfiled becomeFirstResponder];
        self.hideTextfiled.keyboardType =  UIKeyboardTypeNumberPad;
        self.hideTextfiled.delegate = self;
        [self.hideTextfiled addTarget:self action:@selector(textfiledValueChanged:) forControlEvents:UIControlEventEditingChanged];
        self.hideTextfiled.hidden = YES;
        
        UIButton *makeBtn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, VIEWWIDTH, VIEWHEIGHT)];
        makeBtn.backgroundColor=[UIColor blackColor];
        makeBtn.alpha=0.5;
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        [keyWindow addSubview:makeBtn];
        //橘色view
        UIView *juseView=[[UIView alloc]initWithFrame:CGRectMake(16, (VIEWHEIGHT-170)*0.5-70, VIEWWIDTH-32, 48)];
        juseView.backgroundColor=[UIColor orangeColor];
        [keyWindow addSubview:juseView];
        //标题
        UILabel *titleLbl=[[UILabel alloc] initWithFrame:CGRectMake(0, 0,VIEWWIDTH-32, 48)];
        titleLbl.text=@"请输入取件密码";
        titleLbl.textColor=[UIColor whiteColor];
        titleLbl.textAlignment=NSTextAlignmentCenter;
        [juseView addSubview:titleLbl];
        //白色背景
        UIView *baiseView=[[UIView alloc] initWithFrame:CGRectMake(16,CGRectGetMaxY(juseView.frame), VIEWWIDTH-32, 170)];
        baiseView.backgroundColor=[UIColor whiteColor];
        [keyWindow addSubview:baiseView];
        //密码输入框1
        self.firstLable=[[UILabel alloc] initWithFrame:CGRectMake(VIEWWIDTH*0.063*1.1, 50, VIEWWIDTH*0.063*2.2, VIEWWIDTH*0.063*2.2)];
        self.firstLable.layer.borderWidth=1;
        self.firstLable.textColor = [UIColor blackColor];
        //密码输入框2
        self.secondLable=[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.firstLable.frame)+VIEWWIDTH*0.063, 50, VIEWWIDTH*0.063*2.2, VIEWWIDTH*0.063*2.2)];
        self.secondLable.layer.borderWidth=1;
        //密码输入框3
        self.thirdLable=[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.secondLable.frame)+VIEWWIDTH*0.063, 50, VIEWWIDTH*0.063*2.2, VIEWWIDTH*0.063*2.2)];
        self.thirdLable.layer.borderWidth=1;
        //密码输入框4
        self.fourthLable=[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.thirdLable.frame)+VIEWWIDTH*0.063, 50, VIEWWIDTH*0.063*2.2, VIEWWIDTH*0.063*2.2)];
        self.fourthLable.layer.borderWidth=1;
        self.firstLable.textAlignment=NSTextAlignmentCenter;
        self.secondLable.textAlignment=NSTextAlignmentCenter;
        self.thirdLable.textAlignment=NSTextAlignmentCenter;
        self.fourthLable.textAlignment=NSTextAlignmentCenter;
        
        [baiseView addSubview:self.firstLable];
        [baiseView addSubview:self.secondLable];
        [baiseView addSubview:self.thirdLable];
        [baiseView addSubview:self.fourthLable];

    }
    return self;
}
#pragma mark - self.hideTextfiled的代理方法
-(void)textfiledValueChanged:(UITextField *)textfiled{
    
    NSString *str = textfiled.text;
    NSLog(@"%@",str);
    if (str.length==1) {
        self.firstLable.text = [str substringWithRange:NSMakeRange(0, 1)];
    }else if (str.length == 2){
        self.secondLable.text = [str substringWithRange:NSMakeRange(1, 1)];
    }else if (str.length ==3){
        self.thirdLable.text = [str substringWithRange:NSMakeRange(2, 1)];
    }else if (str.length ==4){
        self.fourthLable.text = [str substringWithRange:NSMakeRange(3, 1)];
        //在这里判断密码填写是否正确
    }
    
    if (str.length<self.strLenth) {
        NSLog(@"点击了删除");
        switch (self.strLenth) {
            case 1:
                self.firstLable.text = @"";
                break;
            case 2:
                self.secondLable.text = @"";
                break;
            case 3:
                self.thirdLable.text =@"";
                break;
            case 4:
                self.fourthLable.text = @"";
            default:
                break;
        }
    }
    self.strLenth = str.length;
    
}

@end
