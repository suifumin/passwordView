//
//  passwordView.h
//  仿密码输入框
//
//  Created by suifumin on 2017/11/2.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface passwordView : UIView<UITextFieldDelegate>
/**
 密码输入的第一个lable
 */
@property(nonatomic,strong)UILabel *firstLable;

/**
 密码输入的第二个lable
 */
@property(nonatomic,strong)UILabel*secondLable;

/**
 密码输入的第三个Lable
 */
@property(nonatomic,strong)UILabel*thirdLable;

/**
 密码输入的第四个lable
 */
@property(nonatomic,strong)UILabel*fourthLable;

/**
 隐藏的textfiled
 */
@property(nonatomic,strong)UITextField*hideTextfiled;

/**
 记录上一次textfiled的内容的长度
 */
@property(nonatomic,assign)NSInteger strLenth;
@end
